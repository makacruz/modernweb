let x, y, z;
x = 10;
y = '10';
z = 30;
console.log(`x is ${typeof x}`);
console.log(`y is ${typeof y}`);
console.log(`z is ${typeof z}`);

var newX = x++;
console.log(`newX is ${typeof newX}`);

let timeInMs = Date.now();
console.log(`timeInMs is ${typeof timeInMs}`);
console.log(timeInMs);

let numOne = 1;
let stringOne = '1';
console.log('double ==', numOne == stringOne);
console.log('triple ===', numOne === stringOne);

const day = new Date().getDay();
console.log(day);

function displayName(aValue) {
    console.log('Hello, ' + aValue);
}
displayName('Thomas');

let myArray = ['rollerSkating', 'running', 'weightLifting'];
function printHobbies() {
    console.log('I like ${passedArray.length} things:');
    for (index = 0; index < myArray.length; ++index);
    let element = myArray[index];
    console.log('I like' + element);
}
printHobbies(myArray);

const hobbiesArray = [
    { name: 'rollerSkating', lengthInYearsAtHobby: 30 },
    { name: 'weightLifting', lengthInYearsAtHobby: 20},
    { name: 'running', lengthInYearsAtHobby: 40}
];

function printHobbyInfo(hobby) {
    console.log(` ${hobby.name} enjoyed for ${hobby.lengthInYearsAtHobby} `)
}

for (let x = 0; x < hobbiesArray.length; x++) {
    printHobbyInfo(hobbiesArray[x]);
}

let band1 = {
    name : "Pink Floyd",
    city : "London" ,
    country : "England",
    yearFormed : 1965,
    genres : ["Progressive rock", "psychedelic rock", "art rock"]
}
band1.genres = new Array("Progressive rock2", "psychedelic rock2", "art rock2");

