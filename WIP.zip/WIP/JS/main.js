console.log('Hello World');
console.log('Hello Universe');